<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pertanyaan;
use App\Jawaban;
use Auth;

class PertanyaanController extends Controller
{
    public function index()
    {
        $data_pertanyaan = \App\Pertanyaan::get();
        return view('pertanyaan.index', ['data_pertanyaan' => $data_pertanyaan]);
    }
    
    public function create(Request $request)
    {
        //   Validasi kalo user udah pernah submit
      $cek_jumlah_jawaban = Jawaban::where('user_id', Auth::user()->id)->count();
      if ($cek_jumlah_jawaban < 1) { //Kalo belum pernah submit
            $data_jawaban = [];
            for ($i=0; $i < count($request['id']); $i++) { 
                array_push($data_jawaban, [
                    'id_pertanyaan' => $request['id'][$i],
                    'jawaban' => $request['jawaban'][$request['id'][$i]],
                    'user_id' => Auth::user()->id //Ganti sama user id orang yang login
                ]);
            }
          Jawaban::insert($data_jawaban);
          return redirect('/home');     
      }else{
          return redirect()->back()->with('failure', 'Maaf... Kamu sudah pernah mengikuti pemeriksaan ini');     
      }

    }
}
